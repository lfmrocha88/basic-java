package org.basic.youtube;

public class InscritoListener implements EventListener {
	
	private String nome;
	
	public InscritoListener(String nome) {
		this.nome = nome;
	}

	@Override
	public void update(String eventType) {
		System.out.println("Notificando " + nome + " sobre: " + eventType);
	}

}
