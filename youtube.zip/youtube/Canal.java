package org.basic.youtube;

public class Canal {
	
	public EventManager events;
	
	public String nome;
	
	public Canal(String nome) {
		events = new EventManager("live", "new");
		this.nome = nome;
	}
	
	public void startLive() {
        System.out.println("Live comecou no canal " + nome + "!!!");
        events.notify("live");
    }

    public void newVideo() {
    	System.out.println("Novo video no canal " + nome + "!!!");
        events.notify("new");
    }

}
