package org.basic.youtube;

public interface EventListener {
	
    void update(String eventType);

}
