package org.basic.youtube;

public class Demo {

	public static void main(String[] args) {
		Canal canal = new Canal("Canal do Java");
		
		InscritoListener luis = new InscritoListener("Luis");
		
		canal.events.subscribe("new", luis);
		canal.events.subscribe("live", luis);
		
		canal.startLive();
		canal.newVideo();
		
		canal.events.unsubscribe("live", luis);
		
		InscritoListener jose = new InscritoListener("Jose");
		
		canal.events.subscribe("new", jose);
		
		canal.startLive();
		canal.newVideo();
		
	}
	
}
